<?php

/*
 * General Controller Class
 */

class Controller{
    
    private $controller;
    private $error;
    
    function __construct(){
        
    }
    
    function setController($controller){
        
        $controller_path = "./controllers";
        
        if(file_exists($controller_path . "/" . $controller . ".controller.php")){
            
            $the_controller = $controller_path . "/" . $controller . ".controller.php";
            
            $this->controller = $the_controller;
            
        }else{
            
            $this->controller = null;
            $this->error = true;            
        }
        
    }
    
    function getController(){
        
        if(!is_null($this->controller)){
            return $this->controller;
        }else{
            return $this->error;
        }
        
    }   

}