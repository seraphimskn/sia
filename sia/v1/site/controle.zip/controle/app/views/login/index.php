<?php 
//include_once(BASE_PATH.'/app/controll/login.php');

if(isset($_POST['login']) && $_POST['login'] == 'Entrar'){
	//var_dump($_POST);
	extract($_POST);
	$log = new Login();
	echo $log->log($user, $pass);
}
?>
<div class="log">
<img src="imgs/lockIcon.png" id="lock" />
<form action="" enctype="multipart/form-data" method="post" class="login">
	<div class="field user">
		<input type="text" name="user" placeholder="Digite seu Login" required />
	</div>
	<div class="field pass">
		<input type="password" name="pass" placeholder="Digite sua Senha" required />
	</div>
	<input type="submit" name="login" value="Entrar" />
	<!-- a href="#">Esqueci minha senha!</a -->
</form>
</div>