<?php 

class Login{

	public $error = '';

	private function crip($pass){
		return base64_encode(md5($pass));
	}

	private function validate($user,$pass){
		$val = self::getConn()->prepare('SELECT * FROM `'.T_PREFIX.'users` WHERE `login`=? AND `password`=? LIMIT 1');
		$val->execute(array($user, $this->crip($pass)));
		if($val->rowCount() === 1) return true;
	}

	public function log($user,$pass){
		if($this->validate($user, $pass) == true){
			$sel = self::getConn()->prepare('SELECT * FROM `'.T_PREFIX.'users` WHERE `login`=? AND `password`=? LIMIT 1');
			if($sel->execute(array($user, $this->crip($pass)))){
				$vals = $sel->fetch(PDO::FETCH_ASSOC);
				if(!isset($_SESSION)) session_start();
				$_SESSION['logged'] = 'true';
				$_SESSION['session_user'] = $vals['nome'];
				$_SESSION['nivel'] = $vals['level'];
				$cookie = join('#',array($user,$_SERVER['HTTP_USER_AGENT'],$_SERVER['REMOTE_ADDR']));
				$cookie = sha1($cookie);
				setcookie($_SERVER['SERVER_NAME'].'token',$cookie,0,'/');
				
				echo '<script type="text/javascript">location.href="./"</script>';
			}
		}else{
			return $this->error = '<div class="error" style="font-weight:bold;margin:0 auto;width:25%;text-align:center;color:#900">Usu&aacute;rio ou Senha incorretos! Tente Novamente!</div>';
		}
	}

	public function endSession($quit){
		if(true == $quit){
			unset($_COOKIE[$_SERVER['SERVER_NAME'].'token']);
			unset($_SESSION['session_user']);
			unset($_SESSION['nivel']);
			session_destroy();
		}
	}
}




